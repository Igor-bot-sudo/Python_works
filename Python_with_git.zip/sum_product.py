def product_sum(products: dict) -> int:
    return sum(products.values())

# products = {'Кружка': 300, 'Стакан': 400, 'Кофе': 800}
# print(product_sum(products))
